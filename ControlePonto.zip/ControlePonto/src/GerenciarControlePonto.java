import java.util.Date;

public class GerenciarControlePonto {
    public static void main(String[] args) {
        GerenciarControlePonto gc = new GerenciarControlePonto();

        Gerente gerente = new Gerente();

        System.out.println("Nome do Gerente: " + gerente.getNome());
        System.out.println("ID do Gerente: " + gerente.getIdFunc());
        System.out.println("Email do Gerente: " + gerente.getEmail());
        System.out.println("Documento do Gerente: " + gerente.getDocumento());

        gerente.setNome("Fídel");
        gerente.setIdFunc(1);
        gerente.setEmail("fidel@gmail.com");
        gerente.setDocumento("123.456.789-01");

        Operador telefonista = new Operador();

        System.out.println("Nome do Telefonista: " + telefonista.getNome());
        System.out.println("ID do Telefonista: " + telefonista.getIdFunc());
        System.out.println("Email do Telefonista: " + telefonista.getEmail());
        System.out.println("Documento do Telefonista: " + telefonista.getDocumento());

        telefonista.setNome("Beatriz");
        telefonista.setIdFunc(2);
        telefonista.setEmail("betriz@gmail.com");
        telefonista.setDocumento("987.654.321-01");

        Secretaria secretaria = new Secretaria();

        System.out.println("Nome do Secretaria: " + secretaria.getNome());
        System.out.println("ID do Secretaria: " + secretaria.getIdFunc());
        System.out.println("Email do Secretaria: " + secretaria.getEmail());
        System.out.println("Documento do Secretaria: " + secretaria.getDocumento());

        secretaria.setNome("Jhonatan");
        secretaria.setIdFunc(3);
        secretaria.setEmail("jhonatan@gmail.com");
        secretaria.setDocumento("567.456.329-01");

        ControlePonto registroGerente = new ControlePonto();
        registroGerente.registraEntrada(horaEntrada);



    }
}


