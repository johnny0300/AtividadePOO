import java.time.LocalDateTime;

public class ControlePonto {
    private LocalDateTime dataRegistro;
    private LocalDateTime horaEntrada;
    private LocalDateTime horaSaida;

    Funcionario func = new Funcionario();

    public String registraEntrada(Funcionario func) {
        this.dataRegistro = LocalDateTime.now();
        String horaEntrada = "Entrada de " + func.getNome() + " em " + dataRegistro;
        return horaEntrada;
    }

    public String registraSaida(Funcionario func) {
        this.dataRegistro = LocalDateTime.now();
        String horaSaida = "Saída de " + func.getNome() + " em " + dataRegistro;
        return horaSaida;

    }
}
